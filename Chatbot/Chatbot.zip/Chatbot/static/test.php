<?php
include 'database.php';
echo "Conexión exitosa";
?>
